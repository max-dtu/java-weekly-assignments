package dk.dtu.pets;

public class Dog extends Pet {
    public Dog(String name) {
        super(name, "dog");
    }
}
