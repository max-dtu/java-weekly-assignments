package dk.dtu.pets;

public class Cat extends Pet {
    public Cat(String name) {
        super(name, "cat");
    }
}
