package dk.dtu.pets;

public class Pet {
    private final String name;
    private final String species;

    public Pet(String name, String species) {
        this.name = name;
        this.species = species;
    }

    public String getDescription() {
        return this.name + " (" + this.species + ")";
    }
}
