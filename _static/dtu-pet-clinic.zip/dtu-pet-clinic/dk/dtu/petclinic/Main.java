package dk.dtu.petclinic;

public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome to the DTU Pet Clinic!");

        var pets = new dk.dtu.pets.Pet[] { new dk.dtu.pets.Dog("Dr Wolf"),
                                           new dk.dtu.pets.Dog("Mr Coyote"),
                                           new dk.dtu.pets.Cat("Prof Los"),
                                           new dk.dtu.pets.Cat("Dr Puma")   };

        System.out.println("Current list of pets:");
        for (var p: pets) {
            System.out.println("    - " + p.getDescription());
        }
    }
}
